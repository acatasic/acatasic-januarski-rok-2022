export class Kategorija {
    constructor(id, tip) {
        this.id = id;
        this.tip = tip;
        this.prodKuce=[];
    }
}