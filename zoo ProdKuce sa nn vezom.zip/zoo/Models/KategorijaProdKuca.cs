        
        
        
        
        
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using System.Text.Json.Serialization;
using System;

/*namespace zoo.Models{
   /* [Table("KategorijaProdukcijskaKuca")]*/
  /*  public class KategorijaProdKuca{
        
        [Column("ID")]    
        public int ID{get;set;}
        public int KategorijaID{get;set;}

        [JsonIgnore]
        public Kategorija Kategorija{get;set;}

        public int  ProdukcijskaKucaID{get;set;}
        
        [JsonIgnore]
        public ProdukcijskaKuca ProdukcijskaKuca{get;set;}

        }

 }
 */